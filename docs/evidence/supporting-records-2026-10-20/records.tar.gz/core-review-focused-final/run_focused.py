"""Serial focused measurements against two pinned source snapshots."""

import json
import os
import platform
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
REPOSITORY = Path('/workspace/python-projects')
FINAL = OUT / 'source/final'
BASELINE = OUT / 'source/baseline'
FINAL_SHA = 'a33a513840d81f6e2cdb1b730540d906122bb254'
BASELINE_SHA = '39d3a8d4be3e8e2e7de85379790d68f5367d6825'
THREADS = {
    'OMP_NUM_THREADS': '1',
    'OPENBLAS_NUM_THREADS': '1',
    'MKL_NUM_THREADS': '1',
    'NUMEXPR_NUM_THREADS': '1',
    'VECLIB_MAXIMUM_THREADS': '1',
    'PYTHONDONTWRITEBYTECODE': '1',
    'PYTHONHASHSEED': '0',
    'PYTHONNOUSERSITE': '1',
}
CASES = [
    ('current', '03-current', FINAL, 'join_density.py', ['--baseline', BASELINE_SHA, '--records', '12000']),
    ('pytrace-baseline', '06-pytrace', BASELINE, 'semantic_scaling.py', ['--label', f'baseline-{BASELINE_SHA}']),
    ('pytrace-final', '06-pytrace', FINAL, 'semantic_scaling.py', ['--label', f'final-{FINAL_SHA}']),
    ('routecraft', '09-routecraft', FINAL, 'insertion_work.py', ['--baseline-file', str(BASELINE / 'projects/09-routecraft/src/pp_routecraft/construction/insertion.py')]),
    ('resonance-baseline', '10-resonance', BASELINE, 'core_review.py', []),
    ('resonance-final', '10-resonance', FINAL, 'core_review.py', []),
]


def utc():
    return datetime.now(timezone.utc).isoformat()


def main():
    report = {
        'schema_version': 1,
        'final_commit': FINAL_SHA,
        'baseline_commit': BASELINE_SHA,
        'started_at_utc': utc(),
        'status': 'running',
        'platform': platform.platform(),
        'serial_session': True,
        'host_isolation_claim': 'Other repository tasks idle by coordination; physical-host exclusivity is not established.',
        'environment': THREADS,
        'commands': [],
    }
    for name, project_name, package_root, driver_name, extra in CASES:
        project = FINAL / 'projects' / project_name
        interpreter = REPOSITORY / 'projects' / project_name / '.venv/bin/python'
        environment = dict(os.environ)
        environment.pop('PYTHONHOME', None)
        environment.update(THREADS)
        environment['PYTHONPATH'] = str(package_root / 'projects' / project_name / 'src')
        identity_command = [str(interpreter), '-c', 'import json,platform,sys;from importlib.metadata import distributions;print(json.dumps({"python":platform.python_version(),"executable":sys.executable,"distributions":sorted((d.metadata["Name"],d.version) for d in distributions())}))']
        identity = json.loads(subprocess.check_output(identity_command, cwd=project, env=environment, text=True))
        assert identity['python'] == '3.14.8', identity
        output = OUT / 'results' / f'{name}.json'
        assert not output.exists(), output
        command = [str(interpreter), str(project / 'benchmarks' / driver_name), *extra, '--repetitions', '5', '--output', str(output)]
        entry = {
            'name': name,
            'argv': command,
            'cwd': str(project),
            'environment': {**THREADS, 'PYTHONPATH': environment['PYTHONPATH'], 'PYTHONHOME': None},
            'interpreter_environment': identity,
            'stdout': f'logs/{name}.stdout.txt',
            'stderr': f'logs/{name}.stderr.txt',
            'output': output.relative_to(OUT).as_posix(),
            'started_at_utc': utc(),
        }
        report['commands'].append(entry)
        print(f'START {name}', flush=True)
        started = time.perf_counter()
        with (OUT / entry['stdout']).open('x') as stdout, (OUT / entry['stderr']).open('x') as stderr:
            result = subprocess.run(command, cwd=project, env=environment, stdout=stdout, stderr=stderr, timeout=180)
        entry.update(exit_code=result.returncode, finished_at_utc=utc(), elapsed_seconds=time.perf_counter() - started)
        (OUT / 'commands.json').write_text(json.dumps(report, indent=2) + '\n')
        print(f'FINISH {name}: exit={result.returncode}, elapsed={entry["elapsed_seconds"]:.3f}s', flush=True)
        result.check_returncode()
    report.update(status='completed', finished_at_utc=utc())
    (OUT / 'commands.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()
