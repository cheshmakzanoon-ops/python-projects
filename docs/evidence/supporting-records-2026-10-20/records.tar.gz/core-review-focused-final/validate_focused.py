"""Validate the retained measurements without running measured work again."""

import ast
import hashlib
import json
import math
import statistics
import subprocess
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
FINAL = OUT / 'source/final'
BASE = OUT / 'source/baseline'
PRIMARY = Path('/workspace/python-projects')
PROJECTS = ['03-current', '06-pytrace', '09-routecraft', '10-resonance']
EXPECTED_FINAL = 'a33a513840d81f6e2cdb1b730540d906122bb254'
EXPECTED_BASE = '39d3a8d4be3e8e2e7de85379790d68f5367d6825'


def read(name):
    return json.loads((OUT / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(paths, root, separator=b'\0'):
    value = hashlib.sha256()
    for path in sorted(paths):
        value.update(path.relative_to(root).as_posix().encode() + separator + path.read_bytes())
    return value.hexdigest()


def git(root, *arguments):
    return subprocess.check_output(['git', '--no-optional-locks', *arguments], cwd=root, text=True).strip()


def working_status(root):
    raw = subprocess.check_output(['git', '--no-optional-locks', 'status', '--porcelain=v1', '--no-renames', '-z'], cwd=root)
    entries = [{'status': record[:2].decode(), 'path': record[3:].decode()} for record in raw.split(b'\0') if record]
    return {'clean': not entries, 'entries': entries, 'porcelain_z_sha256': hashlib.sha256(raw).hexdigest()}


def portable(value):
    if isinstance(value, str):
        return value.replace(str(OUT) + '/', '').replace(str(OUT), '.').replace(str(PRIMARY), '$PRIMARY_CHECKOUT')
    if isinstance(value, list):
        return [portable(item) for item in value]
    if isinstance(value, dict):
        return {key: portable(item) for key, item in value.items()}
    return value


def project_digest(root, separator):
    return digest([*root.glob('src/**/*.py'), *root.glob('tests/**/*.py'), root/'pyproject.toml', root/'uv.lock', root/'.python-version'], root, separator)


def timings(values, reported=None):
    assert len(values) == 5 and all(math.isfinite(value) and value >= 0 for value in values)
    median = statistics.median(values)
    if reported is not None:
        assert median == reported
    return median


def package_identity(report, root, project, package):
    expected = root/'projects'/project/'src'/package
    assert Path(report['package_path']) == expected
    files = sorted(expected.rglob('*.py'))
    recorded = report.get('package_content_sha256', report.get('package_python_sha256'))
    assert digest(files, expected) == recorded
    assert report['package_inputs'] == [path.relative_to(expected).as_posix() for path in files]
    assert all(Path(path).is_relative_to(expected) for path in report['imported_modules'].values())
    driver = FINAL/'projects'/project/'benchmarks'/Path(report['workload_path']).name
    assert Path(report['workload_path']) == driver
    assert report['workload_sha256'] == sha(driver)
    assert report['python'] == '3.14.8' and report['repetitions'] == 5 and report['inputs_unchanged']


def main():
    before = read('source-inventory-before.json')
    files = []
    for label, root in [('baseline', BASE), ('final', FINAL)]:
        for name in PROJECTS:
            project = root/'projects'/name
            paths = [*project.joinpath('src').rglob('*'), project/'uv.lock', project/'pyproject.toml', project/'.python-version']
            if label == 'final':
                paths += list(project.joinpath('benchmarks').rglob('*.py'))
            for path in sorted(set(paths)):
                if path.is_file():
                    files.append({'snapshot': label, 'path': path.relative_to(root).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)})
    assert files == before['files']
    assert git(FINAL, 'rev-parse', 'HEAD') == EXPECTED_FINAL
    final_status_after = working_status(FINAL)
    assert final_status_after['clean']
    assert git(PRIMARY, 'rev-parse', 'HEAD') == EXPECTED_FINAL
    primary_status_after = working_status(PRIMARY)
    primary_changed_paths = [entry['path'] for entry in primary_status_after['entries']]
    assert not any(path.startswith('projects/'+name+'/') for path in primary_changed_paths for name in PROJECTS)
    after = {'schema_version': 1, 'checked_at_utc': datetime.now(timezone.utc).isoformat(), 'files': files, 'identical_to_before': True, 'final_clean_after': True, 'primary_clean_after': primary_status_after['clean'], 'primary_status_after': primary_status_after, 'primary_changed_paths_after': primary_changed_paths, 'primary_changes_outside_measured_projects': True}
    (OUT/'source-inventory-after.json').write_text(json.dumps(after, indent=2)+'\n')
    commands = read('commands.json')
    assert commands['status'] == 'completed' and len(commands['commands']) == 6
    assert all(command['exit_code'] == 0 and command['interpreter_environment']['python'] == '3.14.8' for command in commands['commands'])
    for previous, current in zip(commands['commands'], commands['commands'][1:]):
        assert previous['finished_at_utc'] <= current['started_at_utc']
    reports = {name: read('results/'+name+'.json') for name in ['current','pytrace-baseline','pytrace-final','routecraft','resonance-baseline','resonance-final']}

    current = reports['current']
    assert current['baseline_commit'] == EXPECTED_BASE and current['source']['source_commit'] == EXPECTED_FINAL
    assert not current['source']['source_dirty'] and current['repetitions'] == 5
    current_project = FINAL/'projects/03-current'
    driver = current_project/'benchmarks/join_density.py'
    assert current['source']['source_content_sha256'] == project_digest(current_project, b'')
    assert current['driver_sha256'] == sha(driver)
    probe = next(ast.literal_eval(node.value) for node in ast.parse(driver.read_text()).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'PROBE' for target in node.targets))
    assert hashlib.sha256(probe.encode()).hexdigest() == current['probe_sha256']
    assert hashlib.sha256(probe.encode()+b'12000').hexdigest() == current['source']['dataset_id']
    for side in ('baseline','indexed'):
        timings(current[side]['processing_seconds'],current[side]['median_seconds'])
        assert len(current[side]['checks']) == 5
        assert all(check['join_pairs'] == 5 and check['window_results'] == 2 for check in current[side]['checks'])

    py_base, py_final = reports['pytrace-baseline'], reports['pytrace-final']
    for report, root in [(py_base,BASE),(py_final,FINAL)]:
        package_identity(report, root, '06-pytrace', 'pp_pytrace')
        assert [row['functions'] for row in report['measurements']] == [100,300,900]
        for row in report['measurements']:
            timings(row['seconds'],row['median_seconds'])
            assert row['measurement_runs'] == 5 and row['shell_findings'] == row['functions']
    assert py_base['workload_sha256'] == py_final['workload_sha256']
    assert [row['source_sha256'] for row in py_base['measurements']] == [row['source_sha256'] for row in py_final['measurements']]

    route = reports['routecraft']
    route_project = FINAL/'projects/09-routecraft'
    package = route_project/'src/pp_routecraft'
    assert route['source_commit'] == EXPECTED_FINAL and not route['source_dirty']
    assert route['baseline_commit'] == EXPECTED_BASE
    assert route['source_content_sha256'] == project_digest(route_project,b'\0')
    assert route['source_checkout_path'] == str(route_project)
    assert route['imported_package']['path'] == str(package)
    assert route['imported_package']['content_sha256'] == digest([path for path in package.rglob('*') if path.is_file() and (path.suffix == '.py' or path.name == 'py.typed')], package)
    baseline_file = BASE/'projects/09-routecraft/src/pp_routecraft/construction/insertion.py'
    assert route['baseline_file_path'] == str(baseline_file)
    assert route['baseline_file_sha256'] == sha(baseline_file) == '12eb2cb042c2d05a85c31f10a81157fe53f83638bfbc9bfba718e392c19eb883'
    assert route['current_insertion_module']['path'] == str(package/'construction/insertion.py')
    assert route['current_insertion_module']['sha256'] == sha(package/'construction/insertion.py')
    assert route['driver_sha256'] == sha(route_project/'benchmarks/insertion_work.py')
    assert all(route['correctness_checks'].values()) and route['parameters']['measured_pairs'] == 15
    assert route['regret_control']['repetitions'] == 1 and route['regret_control']['plans_identical']
    route_rows = []
    for row in route['cases']:
        assert row['repetitions'] == 5 and row['plans_identical'] and len(row['instance_sha256']) == 64
        stats = {}
        for side in ('baseline','revised'):
            stats[side] = {'median_seconds': timings([sample['elapsed_seconds'] for sample in row[side]])}
            for key in ('schedule_calls','scheduled_customer_visits'):
                assert len({sample[key] for sample in row[side]}) == 1
                stats[side][key] = row[side][0][key]
        route_rows.append({'customers':row['customers'],'instance_sha256':row['instance_sha256'],'objective':row['objective'],**stats})

    resonance_base, resonance_final = reports['resonance-baseline'], reports['resonance-final']
    for report, root in [(resonance_base,BASE),(resonance_final,FINAL)]:
        package_identity(report,root,'10-resonance','pp_resonance')
        assert report['limits']['alignment_repeats'] == report['limits']['audio_repeats'] == 5
        for row in report['alignment']:
            timings(row['seconds'],row['median_seconds'])
        audio = report['dynamic_synthetic_phrase']
        timings(audio['seconds'],audio['median_seconds'])
        assert audio['measurement_runs'] == 5 and audio['eligible_frames'] == 709 and audio['voiced_misses'] == 0
        assert audio['within_10_cents_all_eligible'] == 1.0 and audio['detected_notes'] == audio['truth_notes'] == 14 and audio['detected_onsets'] == 14
    assert resonance_base['workload_sha256'] == resonance_final['workload_sha256']
    for key in ('dataset_sha256','mapping_sha256'):
        assert [row[key] for row in resonance_base['alignment']] == [row[key] for row in resonance_final['alignment']]
    assert resonance_base['dynamic_synthetic_phrase']['dataset_sha256'] == resonance_final['dynamic_synthetic_phrase']['dataset_sha256']

    validation = {'schema_version':1,'passed':True,'checks':{'six_serial_commands_exit_zero':True,'all_requested_measurement_arrays_have_five_samples':True,'all_package_import_paths_and_hashes_match_selected_snapshots':True,'all_driver_hashes_match_final_commit_files':True,'paired_dataset_hashes_match':True,'resonance_alignment_mapping_hashes_match':True,'all_source_and_driver_files_unchanged':True,'measured_final_clone_clean_before_after':True,'primary_clean_before':True,'primary_documentation_edits_recorded_after':True,'routecraft_all_plans_identical_and_verified':True},'inventoried_files':len(files),'limitations':['Routecraft compares only the old insertion module with final support code; its regret control has one declared pair.','Current baseline candidate checks are a full-scan formula; indexed checks are instrumented.','Resonance quality/mapping summary reflects the deterministic reported outputs; semantic witnesses deliberately differ after correctness fixes.','Serial local measurements do not establish physical-host exclusivity, standard-workload performance or production capacity.']}
    (OUT/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
    publication = {'schema_version':1,'kind':'committed-source-focused-core-comparison','final_commit':EXPECTED_FINAL,'baseline_commit':EXPECTED_BASE,'python':'3.14.8','repetitions':5,'serial_session':True,'physical_host_exclusivity_claimed':False,'validation':'validation.json','commands':'commands.json','source_inventory_before':'source-inventory-before.json','source_inventory_after':'source-inventory-after.json','metrics':{'current':{'readings':12000,'baseline_median_seconds':current['baseline']['median_seconds'],'final_median_seconds':current['indexed']['median_seconds'],'baseline_candidate_checks':current['baseline']['checks'][0]['candidate_checks'],'baseline_counter_scope':'full-scan formula','final_candidate_checks':current['indexed']['checks'][0]['candidate_checks'],'final_counter_scope':'engine diagnostic','baseline_peak_process_rss_bytes':current['baseline']['peak_process_rss_bytes'],'final_peak_process_rss_bytes':current['indexed']['peak_process_rss_bytes'],'dataset_sha256':current['source']['dataset_id']},'pytrace':[{'functions':old['functions'],'baseline_median_seconds':old['median_seconds'],'final_median_seconds':new['median_seconds'],'baseline_transfer_steps':old['transfer_steps'],'final_transfer_steps':new['transfer_steps'],'source_sha256':old['source_sha256']} for old,new in zip(py_base['measurements'],py_final['measurements'])],'routecraft':{'scope':route['scope'],'cases':route_rows,'regret_control_pairs':1},'resonance':{'alignment':[{'reference_notes':old['reference_notes'],'detected_notes':old['detected_notes'],'cells':old['cells'],'baseline_median_seconds':old['median_seconds'],'final_median_seconds':new['median_seconds'],'dataset_sha256':old['dataset_sha256'],'mapping_sha256':old['mapping_sha256']} for old,new in zip(resonance_base['alignment'],resonance_final['alignment'])],'audio':{'duration_seconds':12,'baseline_median_seconds':resonance_base['dynamic_synthetic_phrase']['median_seconds'],'final_median_seconds':resonance_final['dynamic_synthetic_phrase']['median_seconds'],'eligible_frames':709,'voiced_misses':0,'within_10_cents_all_eligible':1.0,'truth_and_detected_notes':14,'detected_onsets':14,'peak_input_buffer_samples':resonance_final['dynamic_synthetic_phrase']['peak_input_buffer_samples'],'dataset_sha256':resonance_base['dynamic_synthetic_phrase']['dataset_sha256']}}},'limitations':validation['limitations'],'primary_checkout_after':{'clean':primary_status_after['clean'],'changed_paths':primary_changed_paths,'measured_source':False}}
    artifacts = [OUT/'commands.json',OUT/'source-inventory-before.json',OUT/'source-inventory-after.json',OUT/'validation.json',OUT/'run_focused.py',OUT/'validate_focused.py',*sorted((OUT/'results').glob('*.json')),*sorted((OUT/'logs').glob('*.txt'))]
    publication['evidence_files'] = [{'path':path.relative_to(OUT).as_posix(),'sha256':sha(path),'bytes':path.stat().st_size} for path in artifacts]
    publication['path_normalization'] = {
        'method': 'Parsed JSON values only; replace output-root prefixes with relative paths and the original checkout prefix with $PRIMARY_CHECKOUT. Original measurement bytes remain untouched.',
        'original_output_prefix': str(OUT),
        'original_primary_prefix': str(PRIMARY),
        'original_hash_scope': 'SHA-256 and byte counts refer to original retained files before JSON parsing or path normalization.',
    }
    publication['observations'] = {
        name: {'original_file': 'results/'+name+'.json', 'original_sha256': sha(OUT/'results'/f'{name}.json'), 'original_bytes': (OUT/'results'/f'{name}.json').stat().st_size, 'payload': portable(report)}
        for name, report in reports.items()
    }
    publication['commands'] = {'original_file': 'commands.json', 'original_sha256': sha(OUT/'commands.json'), 'original_bytes': (OUT/'commands.json').stat().st_size, 'payload': portable(commands)}
    publication['validation'] = {'original_file': 'validation.json', 'original_sha256': sha(OUT/'validation.json'), 'payload': portable(validation)}
    publication['source_inventory'] = {
        'before_original_file': 'source-inventory-before.json',
        'before_original_sha256': sha(OUT/'source-inventory-before.json'),
        'before': portable(before),
        'after_original_file': 'source-inventory-after.json',
        'after_original_sha256': sha(OUT/'source-inventory-after.json'),
        'after': portable({key: value for key, value in after.items() if key != 'files'}),
        'after_file_list': 'Identical to the before inventory; embedded once to avoid duplicating236 entries.',
    }
    publication.pop('source_inventory_before', None)
    publication.pop('source_inventory_after', None)
    publication['primary_checkout_after']['status'] = primary_status_after
    (OUT/'publication.json').write_text(json.dumps(publication,indent=2)+'\n')
    print(json.dumps({'validation':validation,'metrics':publication['metrics']},indent=2))


if __name__ == '__main__':
    main()
