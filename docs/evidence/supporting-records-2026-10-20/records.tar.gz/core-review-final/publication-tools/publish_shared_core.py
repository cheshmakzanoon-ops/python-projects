#!/usr/bin/env python3
"""Validate and publish shared review evidence; writing requires --publish.

This reads retained local records and the exact Git commit. It does not run any
suite, build, product, integration, clone, or dependency installation. Raw logs
stay local; portable commands refer to their original inventory hashes.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import re
import subprocess
import sys
import tomllib
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

COMMIT = "a33a513840d81f6e2cdb1b730540d906122bb254"
VERSIONS = ("3.13.16", "3.14.8")
TESTS = 119
MYPY_TARGETS = {
    "scripts/portfolio.py", "scripts/select_projects.py", "scripts/catalog.py",
    "scripts/check_architecture.py", "scripts/test_results.py",
    "scripts/summarize_verification.py",
}
TOOLS = {"pytest", "ruff", "mypy", "mkdocs", "pyyaml"}
LABELS = ("setup", "runtime-before", "tests", "test-outcomes", "ruff-format", "ruff-check", "mypy")
HASH = re.compile(r"[0-9a-f]{64}\Z")


def require(condition: object, message: str) -> None:
    if not condition:
        raise ValueError(message)


def reject_constant(value: str) -> None:
    raise ValueError(f"nonfinite JSON number: {value}")


def read_json(path: Path) -> dict:
    require(path.stat().st_size <= 64 * 1024 * 1024, f"oversized JSON: {path.name}")
    value = json.loads(path.read_text(encoding="utf-8"), parse_constant=reject_constant)
    require(isinstance(value, dict), f"expected JSON object: {path.name}")
    return value


def relative(name: object) -> str:
    require(isinstance(name, str) and bool(name), "missing relative path")
    value = PurePosixPath(name)
    require(bool(value.parts) and not value.is_absolute() and ".." not in value.parts
            and value.as_posix() == name and "\n" not in name and "\x00" not in name,
            f"noncanonical evidence/source path: {name!r}")
    return name


def owned(folder: Path, name: str) -> Path:
    name = relative(name)
    path = folder / name
    require(path.is_file() and not path.is_symlink(), f"missing/unsafe file: {name}")
    require(path.resolve().is_relative_to(folder.resolve()), f"escaped file: {name}")
    require(not any(parent.is_symlink() for parent in path.parents if parent != folder.parent),
            f"symlinked parent: {name}")
    return path


def file_record(path: Path, name: str) -> dict:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": name, "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def inventory_rows(rows: object) -> dict[str, dict]:
    require(isinstance(rows, list) and bool(rows), "missing inventory entries")
    result = {}
    for row in rows:
        require(isinstance(row, dict) and set(row) == {"path", "bytes", "sha256"},
                "invalid inventory entry")
        name = relative(row["path"])
        require(name not in result and type(row["bytes"]) is int and row["bytes"] >= 0
                and isinstance(row["sha256"], str) and HASH.fullmatch(row["sha256"]),
                f"duplicate/malformed inventory entry: {name}")
        result[name] = row
    return result


def read_inventory(folder: Path) -> tuple[dict, dict[str, dict], dict]:
    index = owned(folder, "inventory.json")
    report = read_json(index)
    require(type(report["schema_version"]) is int and report["schema_version"] == 1,
            "unsupported raw inventory schema")
    require(report["scope"] == "all retained evidence files except inventory.json itself",
            "unexpected raw inventory scope")
    files = inventory_rows(report["files"])
    require("inventory.json" not in files, "inventory must not include itself")
    actual = set()
    for path in folder.rglob("*"):
        require(not path.is_symlink(), "raw evidence tree contains a symlink")
        if path.is_file() and path != index:
            actual.add(path.relative_to(folder).as_posix())
    require(actual == set(files), "raw inventory is incomplete or has extra files")
    for name, expected in files.items():
        require(file_record(owned(folder, name), name) == expected,
                f"raw evidence changed: {name}")
    return report, files, file_record(index, "inventory.json")


def utc(value: object) -> datetime:
    require(isinstance(value, str), "timestamp must be text")
    result = datetime.fromisoformat(value)
    require(result.tzinfo is not None and result.utcoffset().total_seconds() == 0,
            "timestamp must identify UTC")
    return result


def git_environment() -> dict[str, str]:
    environment = os.environ.copy()
    for name in list(environment):
        if name.startswith("GIT_"):
            environment.pop(name)
    environment.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull,
                       GIT_TERMINAL_PROMPT="0")
    return environment


def verify_source(repository: Path, before: dict) -> tuple[dict[str, bytes], dict[str, dict]]:
    """Recompute recorded digests from exact committed blobs, never the live tree."""
    environment = git_environment()
    raw = subprocess.check_output(
        ["git", "-C", str(repository), "ls-tree", "-rz", "--full-tree", COMMIT],
        env=environment,
    )
    entries = {}
    for line in raw.split(b"\0"):
        if not line:
            continue
        header, name_bytes = line.split(b"\t", 1)
        mode, kind, object_id = header.split(b" ")
        name = relative(name_bytes.decode("utf-8"))
        require(mode in (b"100644", b"100755") and kind == b"blob", "nonregular tracked source")
        entries[name] = object_id.decode("ascii")
    source = inventory_rows(before["source_files"])
    shared = inventory_rows(before["shared_files"])
    require(before["source_inputs"] == sorted(source, key=PurePosixPath) == sorted(entries, key=PurePosixPath),
            "source capture does not cover the exact committed tree")
    require(before["shared_inputs"] == sorted(shared, key=PurePosixPath) and set(shared) <= set(source),
            "inconsistent shared source inventory")
    require(all(shared[name] == source[name] for name in shared), "shared file identity differs")
    docs = before["documentation_inputs"]
    require(isinstance(docs, list) and docs == sorted(set(docs), key=PurePosixPath) and set(docs) <= set(source),
            "invalid documentation input set")
    # Bind scopes to the reviewed helper and committed shared root declarations.
    require(before["source_scope"] == "all tracked regular files in the detached clone",
            "unexpected complete-source scope")
    require(before["source_digest_algorithm"] ==
            "scripts/evidence.digest: length-framed relative UTF-8 path and file bytes, sorted unique paths",
            "unknown digest algorithm")
    source_digest, shared_digest, docs_digest = (hashlib.sha256() for _ in range(3))
    retained = {}
    needed = {"tooling/quality/uv.lock", "scripts/test_results.py", ".github/workflows/ci.yml",
              "scripts/evidence.py"}
    process = subprocess.Popen(["git", "-C", str(repository), "cat-file", "--batch"],
                               env=environment, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    assert process.stdin is not None and process.stdout is not None
    try:
        for name in sorted(entries, key=PurePosixPath):
            process.stdin.write((entries[name] + "\n").encode("ascii"))
            process.stdin.flush()
            header = process.stdout.readline().split()
            require(len(header) == 3 and header[0].decode() == entries[name] and header[1] == b"blob",
                    "Git object identity/type differs")
            size = int(header[2])
            data = process.stdout.read(size)
            require(len(data) == size and process.stdout.read(1) == b"\n", "short Git object")
            require(source[name] == {"path": name, "bytes": size,
                    "sha256": hashlib.sha256(data).hexdigest()}, f"committed source differs: {name}")
            framed = (len(name.encode()).to_bytes(8, "big") + name.encode()
                      + size.to_bytes(8, "big") + data)
            source_digest.update(framed)
            if name in shared:
                shared_digest.update(framed)
            if name in docs:
                docs_digest.update(framed)
            if name in needed:
                retained[name] = data
        process.stdin.close()
        require(process.wait(timeout=30) == 0, "Git object reader failed")
    finally:
        if process.poll() is None:
            process.kill()
            process.wait()
        if not process.stdin.closed:
            process.stdin.close()
        process.stdout.close()
    for name, digest in (("source_content_sha256", source_digest),
                         ("shared_content_sha256", shared_digest),
                         ("documentation_content_sha256", docs_digest)):
        require(before[name] == digest.hexdigest(), f"committed {name} differs")
    require(before["quality_lockfile_sha256"] == hashlib.sha256(retained["tooling/quality/uv.lock"]).hexdigest(),
            "quality lock identity differs")
    # Avoid executing arbitrary captured code: parse its literal input roots only.
    import ast
    module = ast.parse(retained["scripts/evidence.py"])
    roots = next(ast.literal_eval(node.value) for node in module.body
                 if isinstance(node, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == "ROOT_INPUTS" for t in node.targets))
    require(before["shared_input_roots"] == roots, "shared scope roots differ from commit")
    excluded = next(ast.literal_eval(node.value) for node in module.body
                    if isinstance(node, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == "EXCLUDED_PARTS" for t in node.targets))
    expected_shared = set()
    for root in roots:
        if root in source:
            expected_shared.add(root)
        else:
            for name in source:
                if name.startswith(root + "/") and not excluded.intersection(
                    PurePosixPath(name[len(root) + 1:]).parts
                ):
                    expected_shared.add(name)
    require(set(shared) == expected_shared, "shared scope does not cover committed roots")
    expected_docs = {name for name in source if name.endswith(".md") or PurePosixPath(name).name == "mkdocs.yml"}
    expected_docs.update({"scripts/check_docs.py", "scripts/mkdocs_source_links.py",
                          "tooling/quality/pyproject.toml", "tooling/quality/uv.lock"})
    require(set(docs) == expected_docs, "documentation scope is incomplete")
    return retained, shared


def compact(folder: Path, repository: Path) -> dict:
    require(not folder.is_symlink() and folder.is_dir(), "raw evidence directory must be real")
    _, files, inventory = read_inventory(folder)
    def record(name: str) -> dict:
        require(name in files, f"required raw record not inventoried: {name}")
        return read_json(owned(folder, name))
    run = record("verification.json")
    require(type(run["schema_version"]) is int and run["schema_version"] == 1
            and run["kind"] == "shared-tool-verification" and run["status"] == "passed",
            "shared verification did not pass")
    require(run["source_commit"] == run["requested_source"] == COMMIT,
            "unexpected shared source commit")
    require(run["requested_python_versions"] == list(VERSIONS)
            and type(run["expected_tests_per_interpreter"]) is int
            and run["expected_tests_per_interpreter"] == TESTS,
            "unexpected interpreter/test scope")
    require(run["requested_strict_documentation_runs"] == run["executed_strict_documentation_runs"] == 1,
            "require exactly one requested/executed strict docs run")
    for name in ("source_clean_before", "source_clean_after", "source_detached_before",
                 "source_detached_after", "source_unchanged_after"):
        require(run[name] is True, f"source condition not established: {name}")
    require(run["source_clone_retained"] is False, "unexpected retained verification clone")
    require(utc(run["finished_at_utc"]) >= utc(run["started_at_utc"]), "invalid run timing")
    before, after = record("source-before.json"), record("source-after.json")
    require(before == after and before["source_commit"] == COMMIT and before["clean"] is True
            and before["detached"] is True and before["git_status"] == "",
            "source captures are not clean/detached/unchanged")
    committed, shared_files = verify_source(repository, before)
    targets = run["ci_mypy_targets"]
    require(isinstance(targets, list) and len(targets) == 6 and set(targets) == MYPY_TARGETS,
            "mypy does not cover the six required modules")
    found = re.findall(r"(?m)^\s*- run: uv run --locked --project tooling/quality mypy --strict (.+)$",
                       committed[".github/workflows/ci.yml"].decode())
    import shlex
    require(len(found) == 1 and shlex.split(found[0]) == targets, "mypy targets differ from committed CI")
    commands = run["commands"]
    require(isinstance(commands, list), "missing command records")
    by_name = {}
    for command in commands:
        name = command["name"]
        require(isinstance(name, str) and name not in by_name, "duplicate/invalid command name")
        require(type(command["exit_code"]) is int and command["exit_code"] == 0
                and type(command["process_exit_code"]) is int and command["process_exit_code"] == 0
                and command["status"] == "passed" and command["timed_out"] is False
                and command.get("spawn_failed", False) is False, f"command failed or ambiguous: {name}")
        require(type(command["seconds"]) in (int, float) and math.isfinite(command["seconds"])
                and command["seconds"] >= 0, f"invalid elapsed time: {name}")
        require(utc(run["started_at_utc"]) <= utc(command["started_at_utc"]) <= utc(run["finished_at_utc"]),
                f"command outside run interval: {name}")
        require(command["log"] == name + ".log" and command["log"] in files,
                f"missing/incorrect command log: {name}")
        by_name[name] = command
    clone = run["source_clone"]
    require(isinstance(clone, str) and Path(clone).is_absolute(), "invalid recorded clone path")
    clone_command = by_name["clone"]["command"]
    require(len(clone_command) == 9, "unexpected clone invocation")
    primary = clone_command[-2]
    uv = by_name["uv-version"]["command"][0]
    host_python = by_name["source-before"]["command"][0]
    capture_path = by_name["source-before"]["command"][1]
    raw_prefix = str(Path(capture_path).parent)
    require(Path(capture_path).name == "capture_inputs.py" and Path(primary).is_absolute()
            and Path(uv).is_absolute() and Path(host_python).is_absolute(), "missing runtime path identity")
    expected = {
        "uv-version": ([uv, "--version"], primary),
        "clone": (["git", "-c", "core.hooksPath=/dev/null", "clone", "--quiet", "--no-hardlinks",
                   "--no-checkout", primary, clone], primary),
        "checkout": (["git", "-c", "core.hooksPath=/dev/null", "checkout", "--quiet", "--detach", COMMIT], clone),
        "source-before": ([host_python, capture_path, clone, raw_prefix + "/source-before.json"], clone),
        "source-after": ([host_python, capture_path, clone, raw_prefix + "/source-after.json"], clone),
    }
    # Clone has nine arguments (the executable is included).
    require(clone_command == expected["clone"][0], "unexpected clone source/isolation flags")
    uv_version = owned(folder, by_name["uv-version"]["log"]).read_text().strip()
    require(re.match(r"uv 0\.12\.23(?:\s|$)", uv_version), "unexpected uv tool version")
    locked = {(p["name"], p["version"]) for p in tomllib.loads(committed["tooling/quality/uv.lock"].decode())["package"]}
    test_reader = repository / "scripts/test_results.py"
    require(test_reader.read_bytes() == committed["scripts/test_results.py"], "current JUnit reader differs from verified source")
    spec = importlib.util.spec_from_file_location("_shared_publication_junit", test_reader)
    require(spec is not None and spec.loader is not None, "cannot load JUnit reader")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    matrices = run["interpreters"]
    require(isinstance(matrices, list) and [m["python"] for m in matrices] == list(VERSIONS),
            "incomplete/duplicate interpreter records")
    compact_runtimes = []
    for matrix in matrices:
        version = matrix["python"]
        key = "python" + version.replace(".", "")
        environment = clone + "/.local/venvs/quality-shared-" + version
        prefix = [uv, "run", "--locked", "--python", version, "--project", clone + "/tooling/quality"]
        junit = key + "-pytest.xml"
        outcomes_path = key + "-test-outcomes.json"
        labels = list(LABELS) + (["docs"] if version == "3.14.8" else []) + ["runtime-after"]
        require(matrix["checks"] == [key + "-" + label for label in labels]
                and matrix["status"] == "passed" and matrix["environment"] == environment,
                "interpreter scope/status/environment differs")
        require(matrix["selected_overrides"] == {
            "UV_PROJECT_ENVIRONMENT": environment, "UV_PYTHON": version,
            "MYPY_CACHE_DIR": clone + "/.local/cache/mypy-" + version,
            "RUFF_CACHE_DIR": clone + "/.local/cache/ruff-" + version,
        }, "interpreter selection overrides differ")
        expected[key + "-setup"] = ([uv, "sync", "--locked", "--python", version,
                                       "--project", clone + "/tooling/quality"], clone)
        tails = {
            "tests": ["python", "-m", "pytest", "scripts/tests", "--junitxml", raw_prefix + "/" + junit],
            "test-outcomes": ["python", raw_prefix + "/check_junit.py", clone,
                              raw_prefix + "/" + junit, str(TESTS), raw_prefix + "/" + outcomes_path],
            "ruff-format": ["ruff", "format", "--check", "scripts", "integrations"],
            "ruff-check": ["ruff", "check", "scripts", "integrations"],
            "mypy": ["mypy", "--strict", *targets],
        }
        if version == "3.14.8":
            tails["docs"] = ["python", "scripts/check_docs.py"]
        runtime_before = record(key + "-runtime-before.json")
        runtime_after = record(key + "-runtime-after.json")
        require(runtime_before == runtime_after == matrix["actual_runtime"], "runtime changed or disagrees")
        runtime = runtime_before
        require(runtime["python"] == version and runtime["implementation"] == "CPython"
                and runtime["prefix"] == environment and runtime["cwd"] == clone
                and runtime["executable"] == environment + "/bin/python", "actual runtime was not isolated/exact")
        require(set(runtime["tools"]) == TOOLS
                and all((name, value) in locked for name, value in runtime["tools"].items()),
                "runtime tool versions differ from the lock")
        for label in ("runtime-before", "runtime-after"):
            tails[label] = ["python", raw_prefix + "/runtime_info.py", version, environment,
                            clone, raw_prefix + "/" + key + "-" + label + ".json"]
        for label, tail in tails.items():
            expected[key + "-" + label] = (prefix + tail, clone)
        require(junit in files, "JUnit report not inventoried")
        actual = module.read_junit(owned(folder, junit))
        counts = actual.as_dict()
        require(actual.ready and counts == {"passed": TESTS, "failed": 0, "errors": 0, "skipped": 0},
                "required shared tests did not all execute/pass")
        expected_outcomes = {**counts, "expected_executed_tests": TESTS,
                             "no_skip_failure_error": True, "matches_expected_count": True}
        require(record(outcomes_path) == matrix["tests"] == expected_outcomes,
                "recorded test outcomes differ from actual JUnit")
        compact_runtimes.append({
            "python": version, "status": "passed", "runtime_before": runtime_before,
            "runtime_after": runtime_after, "checks": matrix["checks"], "tests": counts,
            "junit": files[junit], "outcome_record": files[outcomes_path],
            "freshness": "runner requires a nonexistent per-interpreter report before pytest; exact report path/command, inventory and executed outcomes rechecked",
        })
    require(set(by_name) == set(expected) and len(commands) == len(expected) == 22,
            "missing/extra shared command scope")
    for name, (command, cwd) in expected.items():
        require(by_name[name]["command"] == command and by_name[name]["cwd"] == cwd,
                f"unexpected command/source/interpreter: {name}")
    # Rehash a second time so concurrent edits during validation cannot be published.
    _, second_files, second_inventory = read_inventory(folder)
    require(second_files == files and second_inventory == inventory, "raw evidence changed during validation")
    replacements = sorted(((clone, "$VERIFICATION_COPY"), (raw_prefix, "$RAW_SHARED_EVIDENCE"),
                           (primary, "$SOURCE_CHECKOUT")), key=lambda item: len(item[0]), reverse=True)
    def portable(value):
        if isinstance(value, str):
            for original, replacement in replacements:
                value = value.replace(original, replacement)
            return value
        if isinstance(value, list):
            return [portable(item) for item in value]
        if isinstance(value, dict):
            return {name: portable(item) for name, item in value.items()}
        return value
    published_commands = []
    for entry in commands:
        item = portable(entry)
        item["command"][0] = Path(entry["command"][0]).name
        item["log_sha256"] = files[entry["log"]]["sha256"]
        item["log_bytes"] = files[entry["log"]]["bytes"]
        published_commands.append(item)
    return {
        "schema_version": 1, "kind": "shared-tool-verification", "status": "passed",
        "publication_helper": {"name": "publish_shared_core.py", "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},
        "source_commit": COMMIT, "verified_started_at_utc": run["started_at_utc"],
        "verified_finished_at_utc": run["finished_at_utc"],
        "scope": "Shared root tests on CPython 3.13.16/3.14.8 (119 each), scripts/integrations Ruff format/lint, six strict mypy modules per interpreter, one strict documentation/link build on 3.14.8.",
        "source": {name: before[name] for name in ("source_scope", "source_digest_algorithm",
                   "source_content_sha256", "shared_content_sha256", "documentation_content_sha256",
                   "quality_lockfile_sha256", "shared_input_roots")},
        "source_input_count": len(before["source_inputs"]),
        "documentation_input_count": len(before["documentation_inputs"]),
        "shared_files": [shared_files[name] for name in sorted(shared_files)],
        "source_conditions": {name: run[name] for name in ("source_clean_before", "source_clean_after",
                              "source_detached_before", "source_detached_after", "source_unchanged_after")},
        "ci_mypy_targets": targets, "uv_version": uv_version,
        "interpreters": portable(compact_runtimes), "commands": published_commands,
        "tests": {"passed": TESTS * 2, "failed": 0, "errors": 0, "skipped": 0},
        "strict_documentation_runs": 1,
        "numeric_thread_limits": run["numeric_thread_limits"],
        "removed_inherited_selector_names": run["removed_inherited_selector_names"],
        "raw_evidence": {"directory": "$RAW_SHARED_EVIDENCE", "inventory": inventory,
                         "verification_record": files["verification.json"],
                         "files": [files[name] for name in sorted(files)]},
        "publication": "Executables use portable names; clone, primary checkout and raw output prefixes use tokens. Original raw record/inventory/log/JUnit SHA-256 values identify unmodified local files; command path rewriting does not relabel their hashes.",
        "limitations": [
            "Hashes establish local consistency, not signed authenticity against someone replacing both evidence and inventory.",
            "The removed disposable clone is represented by retained captures; committed blobs and all declared source/shared/document digests were independently rehashed from the exact Git commit.",
            "JUnit freshness relies on the retained runner's new-report guard; executed leaf outcomes are independently read with the verified scripts/test_results.py.",
            "Product tests, public integrations, browser checks, focused/standard measurements, and production capacity are separate evidence scopes.",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, default=Path("/workspace/python-projects"))
    parser.add_argument("--input", type=Path, default=Path("/workspace/python-projects/.local/core-review-final/shared"))
    parser.add_argument("--output", type=Path, default=Path("/workspace/python-projects/docs/evidence/core-review-shared-2026-10-20.json"))
    parser.add_argument("--publish", action="store_true", help="Explicitly authorize validation and fresh publication")
    args = parser.parse_args()
    if not args.publish:
        print("Prepared only; no evidence validation or publication executed. Add --publish only when authorized.")
        return 0
    output = args.output.absolute()
    try:
        require(not output.exists() and not output.is_symlink(), "publication output must be fresh")
        require(output.parent.is_dir() and not output.parent.is_symlink(), "publication parent must already exist")
        result = compact(args.input.absolute(), args.repository.resolve(strict=True))
        encoded = (json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()
        descriptor = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
        print(f"Published {output}: 238 shared tests, 22 successful commands, both exact interpreters")
    except (OSError, ValueError, KeyError, TypeError, StopIteration, subprocess.SubprocessError) as error:
        parser.error(str(error))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
