
import hashlib,json,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(root/'scripts'))
from evidence import ROOT_INPUTS,digest,files_under
names=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
paths=[root/name for name in names if name]
if any(not path.is_file() or path.is_symlink() for path in paths):
    raise ValueError('source capture requires tracked regular files')
shared=[path for name in ROOT_INPUTS for path in files_under(root/name)]
source_hash,source_inputs=digest(paths,root)
shared_hash,shared_inputs=digest(shared,root)
docs=[path for path in paths if path.suffix=='.md' or path.name=='mkdocs.yml']
docs += [root/'scripts/check_docs.py',root/'scripts/mkdocs_source_links.py',root/'tooling/quality/pyproject.toml',root/'tooling/quality/uv.lock']
docs_hash,docs_inputs=digest(docs,root)
def inventory(selected):
    return [{'path':str(path.relative_to(root)), 'bytes':path.stat().st_size,
             'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in sorted(set(selected))]
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True)
result={
    'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'detached':subprocess.run(['git','symbolic-ref','-q','HEAD'],cwd=root,stdout=subprocess.DEVNULL).returncode==1,
    'source_scope':'all tracked regular files in the detached clone',
    'source_digest_algorithm':'scripts/evidence.digest: length-framed relative UTF-8 path and file bytes, sorted unique paths',
    'source_content_sha256':source_hash,'source_inputs':source_inputs,
    'shared_input_roots':ROOT_INPUTS,'shared_content_sha256':shared_hash,'shared_inputs':shared_inputs,
    'documentation_content_sha256':docs_hash,'documentation_inputs':docs_inputs,
    'source_files':inventory(paths),'shared_files':inventory(shared),
    'quality_lockfile_sha256':hashlib.sha256((root/'tooling/quality/uv.lock').read_bytes()).hexdigest(),
    'clean':not status,'git_status':status,
}
Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_commit':result['source_commit'],'clean':result['clean'],
                  'detached':result['detached'],'source_files':len(paths),
                  'source_content_sha256':source_hash,'shared_content_sha256':shared_hash}))
