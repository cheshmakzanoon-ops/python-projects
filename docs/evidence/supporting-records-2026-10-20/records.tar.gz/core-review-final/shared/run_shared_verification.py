#!/usr/bin/env python3
"""Verify shared tooling from a supplied clean Git commit; execution is opt-in.

This helper creates only its fresh evidence output and disposable scratch clone.
It never changes the source checkout, its index, or an existing evidence directory.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

VERSIONS = ("3.13.16", "3.14.8")
THREAD_LIMITS = (
    "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "GOTO_NUM_THREADS",
)
SELECTORS = {
    "PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONUSERBASE", "PYTHONWARNINGS",
    "VIRTUAL_ENV", "CONDA_PREFIX", "CONDA_DEFAULT_ENV", "MYPYPATH",
    "UV_PROJECT_ENVIRONMENT", "UV_PROJECT", "UV_WORKING_DIR", "UV_PYTHON",
    "UV_PYTHON_PREFERENCE", "UV_NO_MANAGED_PYTHON", "UV_MANAGED_PYTHON",
    "UV_NO_SYNC", "UV_FROZEN", "UV_LOCKED", "UV_NO_DEV", "UV_DEFAULT_GROUPS",
    "UV_GROUP", "UV_GROUPS", "UV_NO_GROUP", "UV_ALL_GROUPS", "UV_NO_DEFAULT_GROUPS",
    "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_COMMON_DIR",
    "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_CEILING_DIRECTORIES",
}
PREFIXES = ("PYTEST_", "PORTFOLIO_", "MYPY_", "RUFF_", "GIT_CONFIG_")

CAPTURE = r'''
import hashlib,json,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(root/'scripts'))
from evidence import ROOT_INPUTS,digest,files_under
names=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
paths=[root/name for name in names if name]
if any(not path.is_file() or path.is_symlink() for path in paths):
    raise ValueError('source capture requires tracked regular files')
shared=[path for name in ROOT_INPUTS for path in files_under(root/name)]
source_hash,source_inputs=digest(paths,root)
shared_hash,shared_inputs=digest(shared,root)
docs=[path for path in paths if path.suffix=='.md' or path.name=='mkdocs.yml']
docs += [root/'scripts/check_docs.py',root/'scripts/mkdocs_source_links.py',root/'tooling/quality/pyproject.toml',root/'tooling/quality/uv.lock']
docs_hash,docs_inputs=digest(docs,root)
def inventory(selected):
    return [{'path':str(path.relative_to(root)), 'bytes':path.stat().st_size,
             'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in sorted(set(selected))]
status=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True)
result={
    'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'detached':subprocess.run(['git','symbolic-ref','-q','HEAD'],cwd=root,stdout=subprocess.DEVNULL).returncode==1,
    'source_scope':'all tracked regular files in the detached clone',
    'source_digest_algorithm':'scripts/evidence.digest: length-framed relative UTF-8 path and file bytes, sorted unique paths',
    'source_content_sha256':source_hash,'source_inputs':source_inputs,
    'shared_input_roots':ROOT_INPUTS,'shared_content_sha256':shared_hash,'shared_inputs':shared_inputs,
    'documentation_content_sha256':docs_hash,'documentation_inputs':docs_inputs,
    'source_files':inventory(paths),'shared_files':inventory(shared),
    'quality_lockfile_sha256':hashlib.sha256((root/'tooling/quality/uv.lock').read_bytes()).hexdigest(),
    'clean':not status,'git_status':status,
}
Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source_commit':result['source_commit'],'clean':result['clean'],
                  'detached':result['detached'],'source_files':len(paths),
                  'source_content_sha256':source_hash,'shared_content_sha256':shared_hash}))
'''

RUNTIME = r'''
import importlib.metadata,json,platform,sys
from pathlib import Path
result={
 'python':platform.python_version(),'implementation':platform.python_implementation(),
 'executable':sys.executable,'prefix':sys.prefix,'cwd':str(Path.cwd()),
 'tools':{name:importlib.metadata.version(name) for name in ('pytest','ruff','mypy','mkdocs','pyyaml')},
}
Path(sys.argv[4]).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
if result['python']!=sys.argv[1] or result['implementation']!='CPython':
 raise SystemExit('actual interpreter does not match selected CPython')
if Path(sys.prefix).resolve()!=Path(sys.argv[2]).resolve() or Path.cwd().resolve()!=Path(sys.argv[3]).resolve():
 raise SystemExit('quality environment or source working directory is not isolated')
'''

JUNIT = r'''
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1])/'scripts'))
from test_results import read_junit
result=read_junit(Path(sys.argv[2]))
record={**result.as_dict(),'expected_executed_tests':int(sys.argv[3]),
        'no_skip_failure_error':result.ready,
        'matches_expected_count':result.passed==int(sys.argv[3])}
Path(sys.argv[4]).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,sort_keys=True))
raise SystemExit(0 if result.ready and record['matches_expected_count'] else 1)
'''


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def file_record(path: Path, root: Path) -> dict[str, object]:
    return {"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def safe_environment() -> tuple[dict[str, str], list[str]]:
    environment = os.environ.copy()
    removed = sorted(name for name in environment if name in SELECTORS or name.startswith(PREFIXES))
    for name in removed:
        environment.pop(name)
    environment.update({name: "1" for name in THREAD_LIMITS})
    environment.update({
        "UV_CACHE_DIR": "/workspace/.cache/uv", "UV_PYTHON_INSTALL_DIR": "/workspace/.python",
        "UV_LINK_MODE": "copy", "PYTHONNOUSERSITE": "1", "GIT_TERMINAL_PROMPT": "0",
    })
    return environment, removed


def redactions() -> list[str]:
    # No environment dump is retained. Scrub credential-like values if a child
    # happens to echo one; command arguments contain only source/output paths.
    from urllib.parse import unquote, urlsplit
    values = set()
    for name, value in os.environ.items():
        if re.search(r"TOKEN|PASSWORD|SECRET|PRIVATE_KEY|ACCESS_KEY", name, re.I) and len(value) >= 8:
            values.add(value)
        if value.startswith(("http://", "https://")):
            try:
                parsed = urlsplit(value)
                for item in (parsed.password, parsed.username):
                    if item and len(item) >= 8:
                        values.add(item)
                        values.add(unquote(item))
            except ValueError:
                pass
    return sorted(values, key=len, reverse=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, default=Path("/workspace/python-projects"))
    parser.add_argument("--commit", required=True, help="Exact source commit supplied by the reviewer")
    parser.add_argument("--output", type=Path, required=True, help="Fresh evidence directory")
    parser.add_argument("--scratch-root", type=Path, default=Path("/workspace/.shared-verification-work"))
    parser.add_argument("--expected-tests", type=int, default=119)
    parser.add_argument("--execute", action="store_true", help="Explicitly authorize the actual checks")
    args = parser.parse_args()
    if not args.execute:
        print("Prepared only. Add --execute when the final source commit and run are authorized.")
        return 0
    if args.expected_tests < 1:
        parser.error("expected-tests must be positive")
    repository = args.repository.resolve(strict=True)
    if args.output.exists() or args.output.is_symlink():
        parser.error("output must be a new path; existing evidence is never overwritten")
    output = args.output.absolute()
    output.mkdir(parents=True)
    args.scratch_root.mkdir(parents=True, exist_ok=True)
    environment, removed = safe_environment()
    hidden = redactions()
    records: list[dict[str, object]] = []
    versions: list[dict[str, object]] = []
    report: dict[str, object] = {
        "schema_version": 1, "kind": "shared-tool-verification", "status": "running",
        "started_at_utc": now(), "requested_source": args.commit,
        "requested_python_versions": list(VERSIONS), "expected_tests_per_interpreter": args.expected_tests,
        "requested_strict_documentation_runs": 1, "commands": records, "interpreters": versions,
        "removed_inherited_selector_names": removed,
        "numeric_thread_limits": {name: "1" for name in THREAD_LIMITS},
        "log_policy": "combined stdout/stderr; credential-like inherited values redacted; no environment dump",
        "scope": "shared root tests, scripts/integrations Ruff, six CI mypy modules, one strict local-link/docs build; no product or integration workloads",
    }
    copied_runner = output / "run_shared_verification.py"
    shutil.copyfile(Path(__file__), copied_runner)
    helpers = {"capture_inputs": CAPTURE, "runtime_info": RUNTIME, "check_junit": JUNIT}
    for name, source in helpers.items():
        (output / f"{name}.py").write_text(source, encoding="utf-8")

    def scrub(value: str) -> str:
        for token in hidden:
            value = value.replace(token, "[REDACTED]")
        return value

    def run(name: str, command: list[str], cwd: Path, env: dict[str, str], timeout: int = 600) -> dict[str, object]:
        log = output / f"{name}.log"
        if log.exists():
            raise ValueError(f"duplicate command/log name: {name}")
        started = now()
        start = time.monotonic()
        try:
            process = subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, start_new_session=True)
        except OSError as error:
            log.write_text(scrub(f"{type(error).__name__}: {error}\n"), encoding="utf-8")
            entry = {"name": name, "command": command, "cwd": str(cwd),
                     "started_at_utc": started, "seconds": time.monotonic()-start,
                     "process_exit_code": None, "exit_code": 1, "timed_out": False,
                     "status": "failed", "log": log.name, "spawn_failed": True}
            records.append(entry)
            write_json(output / "verification.json", report)
            print(f"{name}: failed (could not start)", flush=True)
            return entry
        timed_out = False
        try:
            try:
                stdout, _ = process.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    stdout, _ = process.communicate(timeout=5)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    stdout, _ = process.communicate()
        except BaseException:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            raise
        finally:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        log.write_text(scrub(stdout), encoding="utf-8")
        entry: dict[str, object] = {
            "name": name, "command": command, "cwd": str(cwd), "started_at_utc": started,
            "seconds": time.monotonic()-start, "process_exit_code": process.returncode,
            "exit_code": 1 if timed_out else process.returncode, "timed_out": timed_out,
            "status": "passed" if process.returncode == 0 and not timed_out else "failed",
            "log": log.name,
        }
        records.append(entry)
        write_json(output / "verification.json", report)
        print(f"{name}: {entry['status']} ({entry['exit_code']})", flush=True)
        return entry

    try:
        uv = shutil.which("uv")
        if uv is None:
            raise RuntimeError("uv is unavailable")
        uv_result = run("uv-version", [uv, "--version"], repository, environment)
        if uv_result["exit_code"] or not (output / "uv-version.log").read_text().startswith("uv 0.12.23"):
            raise RuntimeError("verification requires uv 0.12.23")
        resolved = subprocess.check_output(
            ["git", "rev-parse", "--verify", "--end-of-options", f"{args.commit}^{{commit}}"],
            cwd=repository, env=environment, text=True, stderr=subprocess.PIPE,
        ).strip()
        report["source_commit"] = resolved
        with tempfile.TemporaryDirectory(prefix="shared-source-", dir=args.scratch_root) as folder:
            clone = Path(folder) / "source"
            report["source_clone"] = str(clone)
            cloning = run("clone", ["git", "-c", "core.hooksPath=/dev/null", "clone", "--quiet", "--no-hardlinks", "--no-checkout", str(repository), str(clone)], repository, environment)
            if cloning["exit_code"]:
                raise RuntimeError("source clone failed")
            checkout = run("checkout", ["git", "-c", "core.hooksPath=/dev/null", "checkout", "--quiet", "--detach", resolved], clone, environment)
            if checkout["exit_code"]:
                raise RuntimeError("detached checkout failed")
            capture_command = [sys.executable, str(output / "capture_inputs.py"), str(clone)]
            before_run = run("source-before", capture_command + [str(output / "source-before.json")], clone, environment)
            if before_run["exit_code"]:
                raise RuntimeError("could not capture source inputs")
            before = json.loads((output / "source-before.json").read_text())
            if before["source_commit"] != resolved or not before["clean"] or not before["detached"]:
                raise RuntimeError("verification source is not the requested clean detached commit")
            workflow = (clone / ".github/workflows/ci.yml").read_text()
            lines = re.findall(r"(?m)^\s*- run: uv run --locked --project tooling/quality mypy --strict (.+)$", workflow)
            if len(lines) != 1:
                raise RuntimeError("cannot identify the unique shared strict-mypy CI command")
            targets = shlex.split(lines[0])
            if len(targets) != 6 or len(set(targets)) != 6 or any(
                not re.fullmatch(r"scripts/[A-Za-z0-9_]+\.py", name) or not (clone / name).is_file()
                for name in targets
            ):
                raise RuntimeError("expected six explicit shared Python modules in cloned CI")
            report["ci_mypy_targets"] = targets
            quality = clone / "tooling/quality"
            for version in VERSIONS:
                key = "python" + version.replace(".", "")
                venv = clone / ".local/venvs" / f"quality-shared-{version}"
                selected = environment.copy()
                selected.update({"UV_PROJECT_ENVIRONMENT": str(venv), "UV_PYTHON": version,
                                 "MYPY_CACHE_DIR": str(clone / ".local/cache" / f"mypy-{version}"),
                                 "RUFF_CACHE_DIR": str(clone / ".local/cache" / f"ruff-{version}"),
                                 "MPLCONFIGDIR": str(clone / ".local/cache/matplotlib"),
                                 "XDG_CACHE_HOME": str(clone / ".local/cache")})
                checks: list[str] = []
                matrix: dict[str, object] = {"python": version, "environment": str(venv), "checks": checks,
                                             "status": "running", "selected_overrides": {name: selected[name] for name in ("UV_PROJECT_ENVIRONMENT", "UV_PYTHON", "MYPY_CACHE_DIR", "RUFF_CACHE_DIR")}}
                versions.append(matrix)
                prefix = [uv, "run", "--locked", "--python", version, "--project", str(quality)]
                setup_name = key + "-setup"
                checks.append(setup_name)
                setup = run(setup_name, [uv, "sync", "--locked", "--python", version, "--project", str(quality)], clone, selected)
                if setup["exit_code"]:
                    matrix.update(status="failed", unrun=["runtime", "tests", "test-outcomes", "ruff-format", "ruff-check", "mypy", "docs-if-selected"])
                    continue
                runtime_name = key + "-runtime-before"
                checks.append(runtime_name)
                runtime_path = output / f"{key}-runtime-before.json"
                runtime = run(runtime_name, prefix + ["python", str(output / "runtime_info.py"), version, str(venv), str(clone), str(runtime_path)], clone, selected)
                if runtime["exit_code"]:
                    matrix.update(status="failed", unrun=["tests", "test-outcomes", "ruff-format", "ruff-check", "mypy", "docs-if-selected"])
                    continue
                matrix["actual_runtime"] = json.loads(runtime_path.read_text())
                junit = output / f"{key}-pytest.xml"
                if junit.exists():
                    raise RuntimeError("JUnit report must be a fresh file")
                commands = [
                    ("tests", prefix + ["python", "-m", "pytest", "scripts/tests", "--junitxml", str(junit)]),
                    ("test-outcomes", prefix + ["python", str(output / "check_junit.py"), str(clone), str(junit), str(args.expected_tests), str(output / f"{key}-test-outcomes.json")]),
                    ("ruff-format", prefix + ["ruff", "format", "--check", "scripts", "integrations"]),
                    ("ruff-check", prefix + ["ruff", "check", "scripts", "integrations"]),
                    ("mypy", prefix + ["mypy", "--strict", *targets]),
                ]
                if version == "3.14.8":
                    commands.append(("docs", prefix + ["python", "scripts/check_docs.py"]))
                commands.append(("runtime-after", prefix + ["python", str(output / "runtime_info.py"), version, str(venv), str(clone), str(output / f"{key}-runtime-after.json")]))
                for label, command in commands:
                    name = key + "-" + label
                    checks.append(name)
                    run(name, command, clone, selected)
                outcome_path = output / f"{key}-test-outcomes.json"
                if outcome_path.exists():
                    matrix["tests"] = json.loads(outcome_path.read_text())
                matrix["status"] = "passed" if all(entry["exit_code"] == 0 for entry in records if entry["name"] in checks) else "failed"
            after_run = run("source-after", capture_command + [str(output / "source-after.json")], clone, environment)
            if after_run["exit_code"]:
                raise RuntimeError("could not recapture final source inputs")
            after = json.loads((output / "source-after.json").read_text())
            unchanged = all(before[name] == after[name] for name in ("source_commit", "source_content_sha256", "shared_content_sha256", "documentation_content_sha256", "source_inputs", "shared_inputs"))
            report.update(source_clean_before=before["clean"], source_clean_after=after["clean"],
                          source_detached_before=before["detached"], source_detached_after=after["detached"],
                          source_unchanged_after=unchanged)
            report["status"] = "passed" if unchanged and before["clean"] and after["clean"] and after["detached"] and len(versions)==2 and all(item["status"]=="passed" for item in versions) and all(item["exit_code"]==0 for item in records) else "failed"
    except BaseException as error:
        report["status"] = "failed"
        report["error"] = scrub(f"{type(error).__name__}: {error}")
    finally:
        report["finished_at_utc"] = now()
        report["executed_strict_documentation_runs"] = sum(entry["name"].endswith("-docs") for entry in records)
        report["source_clone_retained"] = False
        write_json(output / "verification.json", report)
        inventory = [file_record(path, output) for path in sorted(output.rglob("*")) if path.is_file() and path.name != "inventory.json"]
        write_json(output / "inventory.json", {"schema_version": 1, "scope": "all retained evidence files except inventory.json itself", "files": inventory})
    print(f"Shared verification: {report['status']}; {output / 'verification.json'}", flush=True)
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
