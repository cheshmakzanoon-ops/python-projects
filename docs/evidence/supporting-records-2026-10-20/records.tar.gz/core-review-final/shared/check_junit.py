
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1])/'scripts'))
from test_results import read_junit
result=read_junit(Path(sys.argv[2]))
record={**result.as_dict(),'expected_executed_tests':int(sys.argv[3]),
        'no_skip_failure_error':result.ready,
        'matches_expected_count':result.passed==int(sys.argv[3])}
Path(sys.argv[4]).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,sort_keys=True))
raise SystemExit(0 if result.ready and record['matches_expected_count'] else 1)
