
import importlib.metadata,json,platform,sys
from pathlib import Path
result={
 'python':platform.python_version(),'implementation':platform.python_implementation(),
 'executable':sys.executable,'prefix':sys.prefix,'cwd':str(Path.cwd()),
 'tools':{name:importlib.metadata.version(name) for name in ('pytest','ruff','mypy','mkdocs','pyyaml')},
}
Path(sys.argv[4]).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,sort_keys=True))
if result['python']!=sys.argv[1] or result['implementation']!='CPython':
 raise SystemExit('actual interpreter does not match selected CPython')
if Path(sys.prefix).resolve()!=Path(sys.argv[2]).resolve() or Path.cwd().resolve()!=Path(sys.argv[3]).resolve():
 raise SystemExit('quality environment or source working directory is not isolated')
