from pathlib import Path
from tempfile import TemporaryDirectory
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier, Event
import json
from fastapi.testclient import TestClient
from pp_proving_ground.artifacts.store import ArtifactStore
from pp_proving_ground.data_contracts.schema import generate
from pp_proving_ground.evaluation.metrics import evaluate
from pp_proving_ground.registry.sqlite import Registry
from pp_proving_ground.serving.service import ServingProcess
from pp_proving_ground.serving.api import create_app
from pp_proving_ground.splits.manifest import freeze
from pp_proving_ground.training.pipeline import fit
import pp_proving_ground.registry.sqlite as module

with TemporaryDirectory(prefix='pg-old-concurrency-') as temporary:
 root=Path(temporary); data=generate(); split=freeze(data)
 result=fit(data,split,'logistic'); store=ArtifactStore(root/'models')
 manifest=store.publish(result,'a'*64,data.identity,split.identity,tuple(f.name for f in data.schema))
 report=evaluate(result,data,split,manifest.identity,bootstrap_repetitions=3)
 registry=Registry(root/'registry.db',store); model=registry.register(manifest.identity,report); registry.promote(model.version,0)
 callers=Barrier(9); release=Event(); calls=[]
 def loader(identity):
  calls.append(identity); callers.wait(10); assert release.wait(10); return store.load(identity)
 process=ServingProcess(registry,loader)
 with ThreadPoolExecutor(max_workers=8) as pool:
  futures=[pool.submit(process.refresh) for _ in range(8)]
  callers.wait(10); duplicate_calls=len(calls); release.set()
  outcomes=[future.result(timeout=10) for future in futures]
 target=Registry(root/'snapshot.db',store); encoded=Event(); resume=Event(); real=module.canonical
 def paused(value):
  data=real(value); encoded.set(); assert resume.wait(10); return data
 module.canonical=paused
 with ThreadPoolExecutor(max_workers=1) as pool:
  pending=pool.submit(target.register,manifest.identity,report); assert encoded.wait(5)
  report.metrics['brier']+=0.001; resume.set(); returned=pending.result(timeout=10)
 module.canonical=real
 identity_mismatch=returned != target.versions()[0]
 entered=Event(); finish=Event()
 def late_loader(identity):
  entered.set(); assert finish.wait(10); return store.load(identity)
 late=ServingProcess(registry,late_loader)
 with ThreadPoolExecutor(max_workers=1) as pool:
  with TestClient(create_app(late,auto_refresh=False)):
   pending=pool.submit(late.refresh); assert entered.wait(5)
  finish.set(); published_after_shutdown=pending.result(timeout=10)
 print(json.dumps({'baseline_revision':'39d3a8d4be3e8e2e7de85379790d68f5367d6825','same_generation_concurrent_callers':8,'actual_deserializations':duplicate_calls,'all_refreshes_returned_true':all(outcomes),'registration_returned_identity_differs_from_persisted':identity_mismatch,'late_load_published_after_asgi_shutdown':published_after_shutdown},indent=2))
