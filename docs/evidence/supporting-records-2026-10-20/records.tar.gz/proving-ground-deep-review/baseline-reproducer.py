from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import numpy as np
from pp_proving_ground.artifacts.store import ArtifactStore
from pp_proving_ground.data_contracts.schema import generate
from pp_proving_ground.evaluation.metrics import evaluate, GatePolicy, metrics
from pp_proving_ground.registry.sqlite import Registry
from pp_proving_ground.serving.service import ServingProcess
from pp_proving_ground.splits.manifest import freeze
from pp_proving_ground.training.pipeline import fit, predict

with TemporaryDirectory(prefix='pg-baseline-core-') as temp:
    data=generate()
    split=freeze(data)
    logistic=fit(data,split,'logistic')
    prior=fit(data,split,'prior')
    store=ArtifactStore(Path(temp)/'models')
    manifest=store.publish(prior,'a'*64,data.identity,split.identity,tuple(f.name for f in data.schema))
    submitted=evaluate(logistic,data,split,manifest.identity,bootstrap_repetitions=3)
    actual=metrics(data.labels[split.indices('validation')],predict(prior.pipeline,data.features[split.indices('validation')]))
    registry=Registry(Path(temp)/'registry.db',store)
    version=registry.register(manifest.identity,submitted)
    registry.promote(version.version,0)
    process=ServingProcess(registry)
    assert process.refresh()
    alias=data.features.copy()
    frozen=replace(data,features=alias)
    original=frozen.identity
    alias.flags.writeable=True
    alias[0,0]=123456
    other=generate(seed=19)
    other_split=freeze(other)
    misbound=store.publish(logistic,'b'*64,other.identity,other_split.identity,tuple(f.name for f in other.schema))
    print(json.dumps({
      'baseline_revision':'39d3a8d4be3e8e2e7de85379790d68f5367d6825',
      'evaluation_laundering':{'submitted_metrics':submitted.metrics,'served_artifact_metrics':actual,'submitted_gate_failures':GatePolicy().judge(submitted),'served_gate_failures':GatePolicy().judge(replace(submitted,metrics=actual)),'accepted_generation':registry.current().generation,'served_estimator':'prior'},
      'dataset_alias_changes_frozen_identity':frozen.identity != original,
      'publication_accepts_wrong_fit_dataset':misbound.dataset_digest == other.identity,
    },indent=2))
